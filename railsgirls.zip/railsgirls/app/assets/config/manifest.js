//= link_tree ../images
//= link_directory ../javascripts .js
//= link_directory ../stylesheets .css
# SASS
*= require devise_bootstrap_views

# LESS
*= require devise_bootstrap_views_less
