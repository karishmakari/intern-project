class Suggest < ApplicationRecord
  belongs_to :idea 
  # validates :commenter, format: { with: /\A[a-zA-Z]+\z/,
  #   message: "only allows letters" }
#     validates :body, format: { with: /\A[a-zA-Z]+\z/,
# message: "only allows letters" }
   
end
