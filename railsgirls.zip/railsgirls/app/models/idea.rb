class Idea < ApplicationRecord
    validates :name, format: { with: /\A[a-zA-Z]*$+\z/,
        message: "only allows letters" }
     # validates :description, format: { with: /\A[a-zA-Z]+\z/,
     #    message: "only allows letters" }
    mount_uploader :picture, PictureUploader
    has_many :suggests, dependent: :destroy
     validates :description, presence: true,
                    length: { minimum: 5 }
    resourcify

end
