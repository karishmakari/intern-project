module SuggestsHelper
end
