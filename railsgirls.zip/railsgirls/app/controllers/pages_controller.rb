class PagesController < ApplicationController
  def info
  end
end
