class ApplicationController < ActionController::Base
  #   rescue_from ActiveRecord::RecordNotFound, with: :record_not_found

  # private

  # def record_not_found
  #   render 'app/idea_controller/destroy ', status: 404
  # end

  protect_from_forgery with: :exception
  before_action :authenticate_user!
end

