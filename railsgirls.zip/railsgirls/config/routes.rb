Rails.application.routes.draw do
  

  resources :suggests
    devise_for :users
     get 'pages/info'
      root to: redirect('/ideas')



    resources :ideas do
        member do 
          post 'upvote'
        end
        resources :suggests

    # resources :homes, only: [:show]

end
    end
  
  # For details on the DSL available within this file, see http://guides.rubyonrails.org/routing.html

