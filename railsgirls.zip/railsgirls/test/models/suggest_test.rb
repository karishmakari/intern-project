require 'test_helper'

class SuggestTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
